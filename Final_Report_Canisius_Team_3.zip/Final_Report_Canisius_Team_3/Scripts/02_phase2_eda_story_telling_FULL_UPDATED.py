import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ===================================================
# DATA MASTERS CHALLENGE OLYMPIAD 2026
# Phase 2: Exploratory Data Analysis & Storytelling
# ===================================================

# ---------------------------------------------------
# 1. Project Paths
# ---------------------------------------------------

PROJECT_PATH = "/Users/fredagyemang/Documents/CANISIUS FOLDER/OLYPMPIAD CHALLENGE"
OUTPUT_PATH = os.path.join(PROJECT_PATH, "OUTPUTS")
EDA_OUTPUT_PATH = os.path.join(OUTPUT_PATH, "EDA_CHARTS")

os.makedirs(EDA_OUTPUT_PATH, exist_ok=True)

CLEAN_FILE = os.path.join(OUTPUT_PATH, "cleaned_athletes_dataset.csv")

# ---------------------------------------------------
# 2. Load Cleaned Dataset
# ---------------------------------------------------

df = pd.read_csv(CLEAN_FILE)

# Important fix:
# When pandas reads the CSV, "None" may be interpreted as missing.
# Recode missing Medal values back to "None".
df["Medal"] = df["Medal"].fillna("None")

# Recreate Medal_Won
df["Medal_Won"] = np.where(df["Medal"] == "None", 0, 1)

print("\n--- CLEANED DATA LOADED ---")
print("Shape:", df.shape)
print(df.head())

print("\n--- COLUMNS ---")
print(df.columns)

print("\n--- MEDAL DISTRIBUTION ---")
print(df["Medal"].value_counts())


# ---------------------------------------------------
# 3. Basic Setup for Storytelling
# ---------------------------------------------------

medal_order = ["Gold", "Silver", "Bronze", "None"]

# Focus group for North America comparison
na_df = df[df["Country"].isin(["USA", "CAN"])].copy()
na_df["Medal_Won"] = np.where(na_df["Medal"] == "None", 0, 1)

# Standard country order and colors used throughout country-comparison charts.
# USA is always blue; Canada is always orange.
country_order = ["USA", "CAN"]
country_colors = {
    "USA": "#4C78A8",   # Blue
    "CAN": "#F58518"    # Orange
}
country_color_list = [country_colors[c] for c in country_order]

print("\n--- USA VS CAN DATA ---")
print("Shape:", na_df.shape)
print(na_df["Country"].value_counts())

print("\n--- USA VS CAN MEDAL COUNTS ---")
print(pd.crosstab(na_df["Country"], na_df["Medal"]))

print("\n--- USA VS CAN MEDAL RATE ---")
print(na_df.groupby("Country")["Medal_Won"].mean().reindex(country_order))


# ---------------------------------------------------
# 4. Chart 1: USA vs Canada Medal Distribution
# ---------------------------------------------------

medal_counts = pd.crosstab(na_df["Country"], na_df["Medal"])
medal_counts = medal_counts.reindex(country_order)
medal_counts = medal_counts[["Gold", "Silver", "Bronze"]]

# Medal colors: gold, silver, bronze
medal_colors = ["#D4AF37", "#C0C0C0", "#CD7F32"]

ax = medal_counts.plot(kind="bar", figsize=(7, 5), color=medal_colors, width=0.75)

plt.title("USA vs Canada Medal Comparison", fontsize=13, weight="bold")
plt.ylabel("Number of Medals")
plt.xlabel("")
plt.xticks(rotation=0)

for container in ax.containers:
    ax.bar_label(container, fontsize=10)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(title="Medal Type", frameon=False)
plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "usa_can_medal_comparison_clean.png"))
plt.show()


# ---------------------------------------------------
# 5. Chart 2: USA vs Canada Medal Conversion Rate
# ---------------------------------------------------

medal_rate = na_df.groupby("Country")["Medal_Won"].mean().reindex(country_order)

fig, ax = plt.subplots(figsize=(6, 4.5))

bars = ax.bar(medal_rate.index, medal_rate.values, color=country_color_list, width=0.55)

plt.title("USA Converts Athletes to Medals More Efficiently", fontsize=13, weight="bold")
plt.ylabel("Medal Conversion Rate")
plt.xlabel("")
plt.ylim(0, 0.6)

ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.0%}"))

for bar in bars:
    height = bar.get_height()
    ax.text(
        bar.get_x() + bar.get_width() / 2,
        height + 0.02,
        f"{height:.1%}",
        ha="center",
        va="bottom",
        fontsize=11,
        weight="bold"
    )

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "usa_can_medal_conversion_rate_clean.png"))
plt.show()


# ---------------------------------------------------
# 6. Chart 3: Athlete Quality Comparison
# ---------------------------------------------------

quality_metrics = [
    "Training_Hours_Per_Week",
    "VO2max",
    "Previous_Olympics",
    "World_Cup_Points_Preseason",
    "Career_Injuries"
]

usa_can_summary = na_df.groupby("Country")[quality_metrics].mean().round(2)
usa_can_summary = usa_can_summary.reindex(country_order)

usa_can_summary = usa_can_summary.rename(columns={
    "Training_Hours_Per_Week": "Training Hours",
    "VO2max": "VO2max",
    "Previous_Olympics": "Previous Olympics",
    "World_Cup_Points_Preseason": "World Cup Points",
    "Career_Injuries": "Career Injuries"
})

print("\n--- ATHLETE QUALITY SUMMARY ---")
print(usa_can_summary)

plot_data = usa_can_summary.T

ax = plot_data.plot(kind="bar", figsize=(8, 5), color=country_color_list, width=0.75)

plt.title("Athlete Quality Comparison: USA vs Canada", fontsize=13, weight="bold")
plt.ylabel("Average Value")
plt.xlabel("")
plt.xticks(rotation=25, ha="right")

for container in ax.containers:
    ax.bar_label(container, fmt="%.1f", fontsize=9)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(title="Country", frameon=False)
plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "usa_can_athlete_quality_clean.png"))
plt.show()


# ---------------------------------------------------
# 7. Sport Portfolio Analysis — Filtered Reliable Sports
# ---------------------------------------------------

sport_medal_rate = df.groupby("Sport")["Medal_Won"].mean().sort_values(ascending=False)

print("\n--- OVERALL MEDAL RATE BY SPORT ---")
print(sport_medal_rate.round(2))

sport_country = na_df.groupby(["Sport", "Country"])["Medal_Won"].mean().unstack().fillna(0)
sport_country = sport_country.reindex(columns=country_order).fillna(0)

sport_counts = na_df.groupby(["Sport", "Country"]).size().unstack().fillna(0).astype(int)
sport_counts = sport_counts.reindex(columns=country_order).fillna(0).astype(int)

# Filter reliable sports: both countries must have at least 3 athletes
valid_sports = sport_counts[(sport_counts >= 3).all(axis=1)].index

sport_country_filtered = sport_country.loc[valid_sports]
sport_counts_filtered = sport_counts.loc[valid_sports]

# Sort filtered sports by USA medal conversion rate
sport_country_filtered = sport_country_filtered.sort_values(by="USA", ascending=False)
sport_counts_filtered = sport_counts_filtered.loc[sport_country_filtered.index]

print("\n--- FILTERED SPORTS: MEDAL CONVERSION RATE ---")
print(sport_country_filtered.round(2))

print("\n--- FILTERED SPORTS: ATHLETE COUNTS ---")
print(sport_counts_filtered)

sport_country.to_csv(os.path.join(OUTPUT_PATH, "usa_can_sport_medal_rate_all.csv"))
sport_country_filtered.to_csv(os.path.join(OUTPUT_PATH, "usa_can_sport_medal_rate_filtered.csv"))
sport_counts.to_csv(os.path.join(OUTPUT_PATH, "usa_can_sport_athlete_counts_all.csv"))
sport_counts_filtered.to_csv(os.path.join(OUTPUT_PATH, "usa_can_sport_athlete_counts_filtered.csv"))


# ---------------------------------------------------
# Chart 4: Filtered Sport Medal Conversion
# ---------------------------------------------------

ax = sport_country_filtered.plot(kind="bar", figsize=(12, 6), color=country_color_list, width=0.75)

plt.title("Medal Conversion Rate by Sport", fontsize=13, weight="bold")
plt.ylabel("Medal Conversion Rate")
plt.xlabel("Sport")
plt.xticks(rotation=35, ha="right")
plt.ylim(0, 1.10)

for container in ax.containers:
    ax.bar_label(container, fmt="%.2f", fontsize=9)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(title="Country", frameon=False)
plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "sport_medal_conversion_filtered_clean.png"))
plt.show()


# ---------------------------------------------------
# Chart 5: Filtered Athlete Allocation by Sport
# ---------------------------------------------------

ax = sport_counts_filtered.plot(kind="bar", figsize=(12, 6), color=country_color_list, width=0.75)

plt.title("Athlete Allocation by Sport: USA vs Canada", fontsize=13, weight="bold")
plt.ylabel("Number of Athletes")
plt.xlabel("Sport")
plt.xticks(rotation=35, ha="right")

for container in ax.containers:
    ax.bar_label(container, fontsize=9)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(title="Country", frameon=False)
plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "sport_athlete_allocation_filtered_clean.png"))
plt.show()


# ---------------------------------------------------
# 8. Full Portfolio Analysis — No Filtering
# ---------------------------------------------------

sport_country_full = (
    na_df.groupby(["Sport", "Country"])["Medal_Won"]
    .mean()
    .reset_index(name="Medal_Rate")
)

sport_counts_full = (
    na_df.groupby(["Sport", "Country"])
    .size()
    .reset_index(name="Athletes")
)

efficiency_full = pd.merge(
    sport_counts_full,
    sport_country_full,
    on=["Sport", "Country"],
    how="left"
)

efficiency_full = efficiency_full[efficiency_full["Athletes"] > 0].copy()

print("\n--- FULL PORTFOLIO EFFICIENCY DATA ---")
print(efficiency_full.sort_values(["Country", "Sport"]))


# ---------------------------------------------------
# Chart 6: Full Portfolio Medal Conversion Rate by Sport
# ---------------------------------------------------

sport_country_full_wide = (
    efficiency_full
    .pivot(index="Sport", columns="Country", values="Medal_Rate")
    .reindex(columns=country_order)
    .fillna(0)
)

sport_country_full_wide["Total"] = sport_country_full_wide.sum(axis=1)
sport_country_full_wide = sport_country_full_wide.sort_values("Total", ascending=False).drop(columns="Total")

ax = sport_country_full_wide.plot(kind="bar", figsize=(13, 6), color=country_color_list, width=0.75)

plt.title("Medal Conversion Rate by Sport: Full Portfolio", fontsize=13, weight="bold")
plt.ylabel("Medal Conversion Rate")
plt.xlabel("Sport")
plt.xticks(rotation=40, ha="right")
plt.ylim(0, 1.10)

for container in ax.containers:
    ax.bar_label(container, fmt="%.2f", fontsize=8)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(title="Country", frameon=False)
plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "sport_medal_conversion_full_clean.png"))
plt.show()


# ---------------------------------------------------
# Chart 7: Full Portfolio Athlete Allocation by Sport
# ---------------------------------------------------

sport_counts_full_wide = (
    efficiency_full
    .pivot(index="Sport", columns="Country", values="Athletes")
    .reindex(columns=country_order)
    .fillna(0)
    .astype(int)
)

sport_counts_full_wide["Total"] = sport_counts_full_wide.sum(axis=1)
sport_counts_full_wide = sport_counts_full_wide.sort_values("Total", ascending=False).drop(columns="Total")

ax = sport_counts_full_wide.plot(kind="bar", figsize=(13, 6), color=country_color_list, width=0.75)

plt.title("Athlete Allocation by Sport: Full Portfolio", fontsize=13, weight="bold")
plt.ylabel("Number of Athletes")
plt.xlabel("Sport")
plt.xticks(rotation=40, ha="right")

for container in ax.containers:
    ax.bar_label(container, fontsize=8)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(title="Country", frameon=False)
plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "sport_athlete_allocation_full_clean.png"))
plt.show()


# ----------------------------------------------------------
# 8. FULL PORTFOLIO: Investment vs Medal Efficiency Scatter
# ----------------------------------------------------------

efficiency_full = (
    na_df.groupby(["Sport", "Country"])
    .agg(
        Athletes=("Athlete_ID", "count"),
        Medal_Rate=("Medal_Won", "mean")
    )
    .reset_index()
)

efficiency_full = efficiency_full[
    efficiency_full["Country"].isin(["USA", "CAN"])
].copy()

efficiency_full = efficiency_full[efficiency_full["Athletes"] > 0]

print("\n--- FULL PORTFOLIO (CLEANED) ---")
print(efficiency_full.sort_values(["Country", "Sport"]))


fig, ax = plt.subplots(figsize=(11, 6.5))

for country in ["USA", "CAN"]:
    temp = efficiency_full[efficiency_full["Country"] == country]

    ax.scatter(
        temp["Athletes"],
        temp["Medal_Rate"],
        s=110,
        color=country_colors[country],
        label=country,
        alpha=0.8
    )


# Label only key strategic points to reduce clutter
key_labels = {
    ("USA", "Alpine Skiing"),
    ("USA", "Freestyle Skiing"),
    ("USA", "Ice Hockey"),
    ("USA", "Figure Skating"),
    ("USA", "Bobsleigh"),
    ("CAN", "Snowboard"),
    ("CAN", "Freestyle Skiing"),
    ("CAN", "Ice Hockey"),
    ("CAN", "Curling"),
    ("CAN", "Alpine Skiing")
}

label_offsets = {
    ("USA", "Alpine Skiing"): (0.12, 0.02),
    ("USA", "Freestyle Skiing"): (0.12, 0.03),
    ("USA", "Ice Hockey"): (0.12, -0.04),
    ("USA", "Figure Skating"): (0.12, 0.02),
    ("USA", "Bobsleigh"): (0.12, 0.02),
    ("CAN", "Snowboard"): (0.12, 0.02),
    ("CAN", "Freestyle Skiing"): (0.25, -0.05),
    ("CAN", "Ice Hockey"): (0.12, 0.03),
    ("CAN", "Curling"): (0.12, 0.03),
    ("CAN", "Alpine Skiing"): (0.12, 0.02),
}

for _, row in efficiency_full.iterrows():
    key = (row["Country"], row["Sport"])

    if key in key_labels:
        dx, dy = label_offsets.get(key, (0.12, 0.02))

        ax.text(
            row["Athletes"] + dx,
            row["Medal_Rate"] + dy,
            row["Sport"],
            fontsize=8
        )


# Reference lines using mean
avg_athletes = efficiency_full["Athletes"].mean()
avg_conversion = efficiency_full["Medal_Rate"].mean()

ax.axvline(avg_athletes, linestyle="--", color="gray", linewidth=1)
ax.axhline(avg_conversion, linestyle="--", color="gray", linewidth=1)


# Quadrant labels
ax.text(avg_athletes + 2.5, avg_conversion + 0.5,
        "Strategic Strengths", fontsize=10, weight="bold")

ax.text(1, avg_conversion + 0.5,
        "High Efficiency", fontsize=10, weight="bold")

ax.text(avg_athletes + 2.5, 0.06,
        "Overinvestment Risk", fontsize=10, weight="bold")

ax.text(1, 0.06,
        "Low Impact Areas", fontsize=10, weight="bold")


# Styling
plt.title("Investment vs Medal Efficiency by Sport: Full Portfolio",
          fontsize=13, weight="bold")
plt.xlabel("Number of Athletes")
plt.ylabel("Medal Conversion Rate")

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(frameon=False)

plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "efficiency_full_clean.png"))
plt.show()

# ---------------------------------------------------
# 9. GDP vs Medal Performance
# ---------------------------------------------------

gdp_summary = (
    na_df.groupby("Country")
    .agg({
        "Country_GDP_per_capita": "mean",
        "Medal_Won": "mean"
    })
    .rename(columns={
        "Country_GDP_per_capita": "GDP per Capita",
        "Medal_Won": "Medal Conversion Rate"
    })
    .reindex(country_order)
)

print("\n--- GDP VS PERFORMANCE ---")
print(gdp_summary)

fig, ax = plt.subplots(figsize=(6, 5))

for country in country_order:
    x = gdp_summary.loc[country, "GDP per Capita"]
    y = gdp_summary.loc[country, "Medal Conversion Rate"]

    ax.scatter(x, y, s=200, color=country_colors[country], label=country)
    ax.text(x + 500, y + 0.01, country, fontsize=11, weight="bold")

plt.title("Resources vs Performance: USA vs Canada", fontsize=13, weight="bold")
plt.xlabel("GDP per Capita")
plt.ylabel("Medal Conversion Rate")

ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.0%}"))

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(frameon=False)

plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "gdp_vs_performance_clean.png"))
plt.show()


# ---------------------------------------------------
# 10. Champion Profiling
# ---------------------------------------------------

df["Medal_Group"] = df["Medal"].replace({
    "Gold": "Gold",
    "Silver": "Other Medal",
    "Bronze": "Other Medal",
    "None": "No Medal"
})

print("\n--- MEDAL GROUP COUNTS ---")
print(df["Medal_Group"].value_counts())

profile_metrics = [
    "Training_Hours_Per_Week",
    "VO2max",
    "Body_Fat_Pct",
    "Reaction_Time_ms",
    "Previous_Olympics",
    "Career_Injuries",
    "World_Cup_Points_Preseason"
]

champion_summary = df.groupby("Medal_Group")[profile_metrics].mean().round(2)
champion_summary = champion_summary.loc[["Gold", "Other Medal", "No Medal"]]

print("\n--- CHAMPION PROFILE SUMMARY ---")
print(champion_summary)

gold_vs_none = (champion_summary.loc["Gold"] - champion_summary.loc["No Medal"]).round(2)

print("\n--- GOLD vs NO MEDAL DIFFERENCE ---")
print(gold_vs_none)

medal_group_colors = ["#D4AF37", "#7F7F7F", "#D9D9D9"]

ax = champion_summary.T.plot(kind="bar", figsize=(12, 6), color=medal_group_colors, width=0.75)

plt.title("Champion Profile: Gold vs Other Medalists vs Non-Medalists", fontsize=13, weight="bold")
plt.ylabel("Average Value")
plt.xlabel("Metric")
plt.xticks(rotation=35, ha="right")

for container in ax.containers:
    ax.bar_label(container, fmt="%.1f", fontsize=8)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(title="Medal Group", frameon=False)
plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "champion_profile_clean.png"))
plt.show()


# ----------------------------------------------------------
# 11. Q2.4 — Age & Performance Window
# ----------------------------------------------------------

import seaborn as sns
import matplotlib.pyplot as plt

# Create Medal_Group
na_df["Medal_Group"] = na_df["Medal"].replace({
    "Gold": "Gold",
    "Silver": "Other Medal",
    "Bronze": "Other Medal",
    "None": "No Medal"
})

# Ensure Age is numeric
na_df["Age"] = pd.to_numeric(na_df["Age"], errors="coerce")

# Drop missing values (important fix)
na_df = na_df.dropna(subset=["Age", "Medal_Group"])


# ---------------------------------------------------
# Plot
# ---------------------------------------------------

plt.figure(figsize=(8, 6))

ax = sns.boxplot(
    data=na_df,
    x="Medal_Group",
    y="Age",
    order=["Gold", "Other Medal", "No Medal"],
    palette={
        "Gold": "#C9A227",
        "Other Medal": "#7f7f7f",
        "No Medal": "#d9d9d9"
    }
)

# ---------------------------------------------------
# Add Median Labels
# ---------------------------------------------------

medians = na_df.groupby("Medal_Group")["Age"].median()

for i, group in enumerate(["Gold", "Other Medal", "No Medal"]):
    median_val = medians[group]
    
    ax.text(
        i,
        median_val + 0.7,
        f"{median_val:.1f}",
        ha='center',
        va='bottom',
        fontsize=10,
        weight='bold',
        color='black'
    )

# ---------------------------------------------------
# Add Sample Sizes (n)
# ---------------------------------------------------

counts = na_df["Medal_Group"].value_counts()

for i, group in enumerate(["Gold", "Other Medal", "No Medal"]):
    n = counts[group]
    
    ax.text(
        i,
        na_df["Age"].min() - 1,
        f"n={n}",
        ha='center',
        fontsize=8,
        color='gray'
    )


# ---------------------------------------------------
# Styling
# ---------------------------------------------------

plt.title("Age Distribution by Medal Outcome", fontsize=13, weight="bold")
plt.xlabel("Medal Group")
plt.ylabel("Age")

sns.despine()

plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "age_distribution_medal_groups.png"))
plt.show()


# ----------------------------------------------------------
# 12. Q2.4 — Experience vs Medal Outcome (Box Plot)
# ----------------------------------------------------------

# Ensure required columns are clean
# Convert Previous_Olympics to numeric (handles any bad values)
na_df["Previous_Olympics"] = pd.to_numeric(na_df["Previous_Olympics"], errors="coerce")

# Drop rows with missing values in key fields
na_df_exp = na_df.dropna(subset=["Previous_Olympics", "Medal_Group"]).copy()


# ---------------------------------------------------
# Plot: Olympic Experience vs Medal Outcome
# ---------------------------------------------------

import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(8, 6))

# Create boxplot
ax = sns.boxplot(
    data=na_df_exp,
    x="Medal_Group",
    y="Previous_Olympics",
    order=["Gold", "Other Medal", "No Medal"],  # ensures logical ordering
    palette={
        "Gold": "#C9A227",
        "Other Medal": "#7f7f7f",
        "No Medal": "#d9d9d9"
    }
)


# ---------------------------------------------------
# Add Median Labels (key insight for interpretation)
# ---------------------------------------------------

medians = na_df_exp.groupby("Medal_Group")["Previous_Olympics"].median()

for i, group in enumerate(["Gold", "Other Medal", "No Medal"]):
    median_val = medians[group]
    
    ax.text(
        i,
        median_val + 0.1,                 # slight vertical offset
        f"{median_val:.1f}",
        ha='center',
        va='bottom',
        fontsize=10,
        weight='bold',
        color='black'
    )


# ---------------------------------------------------
# Add Sample Sizes (n) for credibility
# ---------------------------------------------------

counts = na_df_exp["Medal_Group"].value_counts()

for i, group in enumerate(["Gold", "Other Medal", "No Medal"]):
    n = counts[group]
    
    ax.text(
        i,
        na_df_exp["Previous_Olympics"].min() - 0.3,   # place below boxes
        f"n={n}",
        ha='center',
        fontsize=8,
        color='gray'
    )


# ---------------------------------------------------
# Styling
# ---------------------------------------------------

plt.title("Olympic Experience by Medal Outcome", fontsize=13, weight="bold")
plt.xlabel("Medal Group")
plt.ylabel("Previous Olympic Appearances")

sns.despine()

plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "experience_by_medal.png"))
plt.show()




# ----------------------------------------------------------
# Q2.5 — GDP, Tradition, and Sport Type Effects (USA vs CAN)
# ----------------------------------------------------------
# Purpose:
# This analysis checks whether medal conversion differs by sport type.
# It helps answer whether GDP/resources matter more in equipment-heavy
# sports, and whether tradition/program structure matters in technical,
# endurance, or team-based sports.

# ---------------------------------------------------
# 1. Define sport categories
# ---------------------------------------------------

equipment_sports = [
    "Alpine Skiing",
    "Bobsleigh",
    "Luge",
    "Snowboard",
    "Freestyle Skiing"
]

endurance_sports = [
    "Cross-Country",
    "Biathlon",
    "Speed Skating",
    "Short Track"
]

skill_technical_sports = [
    "Figure Skating",
    "Curling",
    "Nordic Combined"
]

team_sports = [
    "Ice Hockey"
]

# ---------------------------------------------------
# 2. Create Sport_Type column
# ---------------------------------------------------
# np.select allows us to classify sports into more than two groups.
# Any sport not listed above will be labeled as "Other".

na_df["Sport_Type"] = np.select(
    [
        na_df["Sport"].isin(equipment_sports),
        na_df["Sport"].isin(endurance_sports),
        na_df["Sport"].isin(skill_technical_sports),
        na_df["Sport"].isin(team_sports)
    ],
    [
        "Equipment-Intensive",
        "Endurance",
        "Technical/Skill",
        "Team"
    ],
    default="Other"
)

# ---------------------------------------------------
# 3. Keep only classified sport types
# ---------------------------------------------------
# We remove "Other" so the chart focuses on meaningful sport categories.

sport_type_df = na_df[
    na_df["Sport_Type"].isin([
        "Equipment-Intensive",
        "Endurance",
        "Technical/Skill",
        "Team"
    ])
].copy()

# ---------------------------------------------------
# 4. Build summary table
# ---------------------------------------------------
# Medal_Conversion_Rate = share of athletes in that sport type who won a medal
# Athletes = number of athletes representing that country in that sport type
# GDP and Tradition Index are averaged within each country/sport type group

sport_type_summary = (
    sport_type_df.groupby(["Sport_Type", "Country"])
    .agg(
        Medal_Conversion_Rate=("Medal_Won", "mean"),
        GDP_per_Capita=("Country_GDP_per_capita", "mean"),
        Tradition_Index=("Winter_Sport_Tradition_Index", "mean"),
        Athletes=("Athlete_ID", "count")
    )
    .reset_index()
)

# Keep USA and Canada only for this comparison
sport_type_summary = sport_type_summary[
    sport_type_summary["Country"].isin(["USA", "CAN"])
].copy()

print("\n--- USA/CAN SPORT TYPE SUMMARY ---")
print(sport_type_summary)

# ---------------------------------------------------
# 5. Plot medal conversion by sport type
# ---------------------------------------------------

plt.figure(figsize=(10, 5.5))

ax = sns.barplot(
    data=sport_type_summary,
    x="Sport_Type",
    y="Medal_Conversion_Rate",
    hue="Country",
    hue_order=["USA", "CAN"],
    order=[
        "Equipment-Intensive",
        "Endurance",
        "Technical/Skill",
        "Team"
    ],
    palette={
        "USA": "#4C78A8",
        "CAN": "#F58518"
    }
)

# Add data labels to bars
for container in ax.containers:
    ax.bar_label(container, fmt="%.2f", fontsize=9, padding=3)

# ---------------------------------------------------
# 6. Styling
# ---------------------------------------------------

plt.title("Medal Conversion by Sport Type: USA vs Canada", fontsize=13, weight="bold")
plt.xlabel("Sport Type")
plt.ylabel("Medal Conversion Rate")

ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.0%}"))

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.ylim(0, 1.05)

plt.legend(title="Country", frameon=False)

plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "medal_conversion_by_sport_type_usa_can.png"))
plt.show()



# ----------------------------------------------------------
# Q2.5 — Proper Correlation (Sport-Level)
# ----------------------------------------------------------

# Keep only relevant sport types
sport_type_df = na_df[
    na_df["Sport_Type"].isin(["Equipment-Intensive", "Endurance"])
].copy()

# ----------------------------------------------------------
# Aggregate at SPORT + COUNTRY level (NOT just country)
# ----------------------------------------------------------

sport_summary = (
    sport_type_df.groupby(["Sport", "Country", "Sport_Type"])
    .agg(
        Medal_Conversion_Rate=("Medal_Won", "mean"),
        GDP_per_Capita=("Country_GDP_per_capita", "mean"),
        Tradition_Index=("Winter_Sport_Tradition_Index", "mean")
    )
    .reset_index()
)

print("\n--- SPORT LEVEL SUMMARY ---")
print(sport_summary.head())

# ----------------------------------------------------------
# Run correlation (NOW REAL)
# ----------------------------------------------------------

print("\n--- CORRELATION RESULTS (FIXED) ---")

for sport_type in ["Equipment-Intensive", "Endurance"]:
    
    temp = sport_summary[
        sport_summary["Sport_Type"] == sport_type
    ]
    
    gdp_corr = temp["GDP_per_Capita"].corr(temp["Medal_Conversion_Rate"])
    tradition_corr = temp["Tradition_Index"].corr(temp["Medal_Conversion_Rate"])
    
    print(f"\n{sport_type}:")
    print(f"  GDP vs Performance: {gdp_corr:.3f}")
    print(f"  Tradition vs Performance: {tradition_corr:.3f}")



# ----------------------------------------------------------
# Q2.6 — Physiological Signature of Champions
# VO2max vs Training Load
# ----------------------------------------------------------

# Create Medal_Group if not already created
na_df["Medal_Group"] = na_df["Medal"].replace({
    "Gold": "Gold",
    "Silver": "Other Medal",
    "Bronze": "Other Medal",
    "None": "No Medal"
})

# Ensure numeric columns
na_df["VO2max"] = pd.to_numeric(na_df["VO2max"], errors="coerce")
na_df["Training_Hours_Per_Week"] = pd.to_numeric(
    na_df["Training_Hours_Per_Week"], errors="coerce"
)

# Drop missing values
phys_df = na_df.dropna(
    subset=["VO2max", "Training_Hours_Per_Week", "Medal_Group", "Country"]
).copy()

plt.figure(figsize=(9, 6))

ax = sns.scatterplot(
    data=phys_df,
    x="Training_Hours_Per_Week",
    y="VO2max",
    hue="Medal_Group",
    style="Country",
    s=90,
    palette={
        "Gold": "#C9A227",
        "Other Medal": "#7f7f7f",
        "No Medal": "#d9d9d9"
    }
)

plt.title("VO2max and Training Load by Medal Outcome", fontsize=13, weight="bold")
plt.xlabel("Training Hours per Week")
plt.ylabel("VO2max")

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

plt.legend(frameon=False, bbox_to_anchor=(1.05, 1), loc="upper left")

plt.tight_layout()
plt.savefig(os.path.join(EDA_OUTPUT_PATH, "vo2_training_signature.png"))
plt.show()
