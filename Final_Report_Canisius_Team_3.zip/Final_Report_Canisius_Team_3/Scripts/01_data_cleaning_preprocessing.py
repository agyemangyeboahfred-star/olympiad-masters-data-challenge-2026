import os
import pandas as pd
import numpy as np

# ===================================================
# DATA MASTERS CHALLENGE OLYMPIAD 2026
# Phase 1: Data Exploration, Cleaning & Preprocessing
# ===================================================

# ---------------------------------------------------
# 1. Project Paths
# ---------------------------------------------------

PROJECT_PATH = "/Users/fredagyemang/Documents/CANISIUS FOLDER/OLYPMPIAD CHALLENGE"
DATA_PATH = os.path.join(PROJECT_PATH, "DATA")
OUTPUT_PATH = os.path.join(PROJECT_PATH, "OUTPUTS")

# Create output folder 
os.makedirs(OUTPUT_PATH, exist_ok=True)

RAW_FILE = os.path.join(DATA_PATH, "milan_cortina_2026_athletes.csv")

# ---------------------------------------------------
# 2. Load Raw Dataset
# ---------------------------------------------------

df_raw = pd.read_csv(RAW_FILE)

print("\n--- RAW DATA LOADED SUCCESSFULLY ---")
print("Raw shape:", df_raw.shape)

# Save a copy of the raw dataset BEFORE cleaning
raw_output_file = os.path.join(OUTPUT_PATH, "raw_athletes_dataset_with_issues.csv")
df_raw.to_csv(raw_output_file, index=False)

print("Raw dataset saved to:", raw_output_file)

# ---------------------------------------------------
# 3. Initial Data Audit
# ---------------------------------------------------

print("\n--- DATA INFO ---")
df_raw.info()

print("\n--- FIRST 5 ROWS ---")
print(df_raw.head())

print("\n--- DESCRIPTIVE STATISTICS ---")
print(df_raw.describe())

# ---------------------------------------------------
# 4. Missing Value Analysis
# ---------------------------------------------------

print("\n--- MISSING VALUES ---")

missing = df_raw.isnull().sum().sort_values(ascending=False)
missing_pct = (missing / len(df_raw)) * 100

missing_table = pd.DataFrame({
    "Missing_Count": missing,
    "Missing_%": missing_pct.round(2)
})

print(missing_table)

# Save missing value summary
missing_output_file = os.path.join(OUTPUT_PATH, "missing_value_summary_raw.csv")
missing_table.to_csv(missing_output_file)

print("Missing value summary saved to:", missing_output_file)

# ---------------------------------------------------
# 5. MNAR Missingness Checks
# Reaction Time and World Cup Points are expected to
# have sport-systematic missingness.
# ---------------------------------------------------

print("\n--- REACTION TIME MISSINGNESS BY SPORT ---")
reaction_missing_by_sport = df_raw.groupby("Sport")["Reaction_Time_ms"].apply(
    lambda x: x.isnull().mean()
).sort_values(ascending=False)

print(reaction_missing_by_sport)

print("\n--- WORLD CUP POINTS MISSINGNESS BY SPORT ---")
worldcup_missing_by_sport = df_raw.groupby("Sport")["World_Cup_Points_Preseason"].apply(
    lambda x: x.isnull().mean()
).sort_values(ascending=False)

print(worldcup_missing_by_sport)

# Save MNAR summaries
reaction_missing_by_sport.to_csv(os.path.join(OUTPUT_PATH, "reaction_time_missing_by_sport.csv"))
worldcup_missing_by_sport.to_csv(os.path.join(OUTPUT_PATH, "worldcup_points_missing_by_sport.csv"))

# ---------------------------------------------------
# 6. Identify Planted Errors
# We are checking for impossible or unrealistic values.
# ---------------------------------------------------

print("\n--- CHECK AGE ---")
print(df_raw["Age"].describe())

print("\n--- CHECK TRAINING HOURS ---")
print(df_raw["Training_Hours_Per_Week"].describe())

print("\n--- CHECK BODY FAT ---")
print(df_raw["Body_Fat_Pct"].describe())

print("\n--- CHECK VO2MAX ---")
print(df_raw["VO2max"].describe())

# Flag planted errors
planted_errors = df_raw[
    (df_raw["Age"] < 15) |
    (df_raw["Training_Hours_Per_Week"] > 80) |
    (df_raw["Body_Fat_Pct"] > 50) |
    (df_raw["VO2max"] < 0)
]

print("\n--- PLANTED ERRORS IDENTIFIED ---")
print(planted_errors)

planted_errors.to_csv(os.path.join(OUTPUT_PATH, "identified_planted_errors.csv"), index=False)

# ---------------------------------------------------
# 7. Duplicate Checks
# There are no exact duplicates, but there are hidden
# logical duplicates based on Athlete_Name, Country, Sport.
# ---------------------------------------------------

print("\n--- EXACT DUPLICATES ---")
exact_duplicates = df_raw[df_raw.duplicated()]
print("Exact duplicate count:", df_raw.duplicated().sum())
print(exact_duplicates)

print("\n--- POTENTIAL HIDDEN DUPLICATES ---")
hidden_duplicates = df_raw[
    df_raw.duplicated(subset=["Athlete_Name", "Country", "Sport"], keep=False)
].sort_values(by=["Athlete_Name", "Country", "Sport"])

print(hidden_duplicates)

hidden_duplicates.to_csv(os.path.join(OUTPUT_PATH, "hidden_duplicate_records.csv"), index=False)

# ---------------------------------------------------
# 8. Create Cleaning Copy
#  We don't want to clean the raw dataset directly.
# ---------------------------------------------------

df_clean = df_raw.copy()

# ---------------------------------------------------
# 9. Correct Planted Errors
# Impossible values are replaced with NaN first.
# They will later be imputed using sport-level averages.
# ---------------------------------------------------

df_clean.loc[df_clean["Age"] < 15, "Age"] = np.nan
df_clean.loc[df_clean["Training_Hours_Per_Week"] > 80, "Training_Hours_Per_Week"] = np.nan
df_clean.loc[df_clean["Body_Fat_Pct"] > 50, "Body_Fat_Pct"] = np.nan
df_clean.loc[df_clean["VO2max"] < 0, "VO2max"] = np.nan

print("\n--- PLANTED ERRORS REPLACED WITH NaN ---")

# ---------------------------------------------------
# 10. Handle Medal Column
# Missing Medal values represent athletes with no medal.
# Therefore, we replace NaN with "None".
# ---------------------------------------------------

df_clean["Medal"] = df_clean["Medal"].fillna("None")

# ---------------------------------------------------
# 11. Remove Hidden Duplicates
# Keep one record per Athlete_Name, Country, and Sport.
# ---------------------------------------------------

before_dedup_shape = df_clean.shape

df_clean = df_clean.drop_duplicates(
    subset=["Athlete_Name", "Country", "Sport"],
    keep="first"
)

after_dedup_shape = df_clean.shape

print("\n--- DUPLICATES REMOVED ---")
print("Before duplicate removal:", before_dedup_shape)
print("After duplicate removal:", after_dedup_shape)

# ---------------------------------------------------
# 12. Impute Missing Values
# Strategy:
# - We use sport-level median for athlete performance variables.
# - This preserves sport-specific differences.
# - Reaction_Time_ms and World_Cup_Points_Preseason are MNAR,
#   so we add missingness flags before imputation.
# ---------------------------------------------------

# Missingness flags for MNAR columns
df_clean["Reaction_Time_Missing_Flag"] = df_clean["Reaction_Time_ms"].isnull().astype(int)
df_clean["World_Cup_Points_Missing_Flag"] = df_clean["World_Cup_Points_Preseason"].isnull().astype(int)

# Columns to impute by sport median
sport_impute_cols = [
    "Age",
    "Training_Hours_Per_Week",
    "Altitude_Training_m",
    "Body_Fat_Pct",
    "VO2max",
    "Reaction_Time_ms",
    "World_Cup_Points_Preseason"
]

for col in sport_impute_cols:
    df_clean[col] = df_clean.groupby("Sport")[col].transform(
        lambda x: x.fillna(x.median())
    )

# If any sport has all missing values for a column, sport median will not work.
# So we use overall median as a final backup.
for col in sport_impute_cols:
    df_clean[col] = df_clean[col].fillna(df_clean[col].median())

print("\n--- MISSING VALUES IMPUTED ---")

# ---------------------------------------------------
# 13. Feature Engineering
# We create new features that may improve EDA and modeling.
# ---------------------------------------------------

# Binary medal indicator for modeling
df_clean["Medal_Won"] = np.where(df_clean["Medal"] == "None", 0, 1)

# Gold indicator for special analysis
df_clean["Gold_Won"] = np.where(df_clean["Medal"] == "Gold", 1, 0)

# VO2 efficiency relative to body fat
df_clean["VO2_BodyFat_Efficiency"] = df_clean["VO2max"] / df_clean["Body_Fat_Pct"]

# Experience-load interaction
df_clean["Experience_Load_Index"] = (
    df_clean["Previous_Olympics"] * df_clean["Training_Hours_Per_Week"]
)

# Resource strength measure
df_clean["Resource_Tradition_Score"] = (
    df_clean["Country_GDP_per_capita"] * df_clean["Winter_Sport_Tradition_Index"]
)

print("\n--- FEATURE ENGINEERING COMPLETE ---")

# ---------------------------------------------------
# 14. Final Validation
# ---------------------------------------------------

print("\n--- FINAL CLEANED DATA INFO ---")
df_clean.info()

print("\n--- FINAL MISSING VALUES ---")
print(df_clean.isnull().sum())

print("\n--- CLEANED DATA SHAPE ---")
print("Raw shape:", df_raw.shape)
print("Cleaned shape:", df_clean.shape)

# ---------------------------------------------------
# 15. Save Cleaned Dataset
# ---------------------------------------------------

clean_output_file = os.path.join(OUTPUT_PATH, "cleaned_athletes_dataset.csv")
df_clean.to_csv(clean_output_file, index=False)

print("\n--- FILES SAVED SUCCESSFULLY ---")
print("Raw dataset:", raw_output_file)
print("Cleaned dataset:", clean_output_file)
print("Missing summary:", missing_output_file)

# ---------------------------------------------------
# 16. Before vs After Summary Table
# ---------------------------------------------------

summary_table = pd.DataFrame({
    "Metric": [
        "Rows",
        "Columns",
        "Exact Duplicates",
        "Hidden Logical Duplicate Rows",
        "Planted Errors Identified",
        "Missing Medal Values",
        "Final Missing Values"
    ],
    "Before Cleaning": [
        df_raw.shape[0],
        df_raw.shape[1],
        df_raw.duplicated().sum(),
        len(hidden_duplicates),
        len(planted_errors),
        df_raw["Medal"].isnull().sum(),
        df_raw.isnull().sum().sum()
    ],
    "After Cleaning": [
        df_clean.shape[0],
        df_clean.shape[1],
        df_clean.duplicated().sum(),
        0,
        0,
        df_clean["Medal"].isnull().sum(),
        df_clean.isnull().sum().sum()
    ]
})

print("\n--- BEFORE VS AFTER CLEANING SUMMARY ---")
print(summary_table)

summary_table.to_csv(os.path.join(OUTPUT_PATH, "before_after_cleaning_summary.csv"), index=False)
