# ==========================================================
# DATA MASTERS CHALLENGE OLYMPIAD 2026
# Phase 3: Binary Predictive Modeling
# Model: Logistic Regression with SMOTE
# Target: Medal_Won (1 = Medal, 0 = No Medal)
# ==========================================================

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    roc_curve,
    confusion_matrix,
    ConfusionMatrixDisplay,
    classification_report
)

from imblearn.over_sampling import SMOTE


# ----------------------------------------------------------
# 1. Project Paths
# ----------------------------------------------------------
# Update PROJECT_PATH to match your local folder.

PROJECT_PATH = "/Users/fredagyemang/Documents/CANISIUS FOLDER/OLYPMPIAD CHALLENGE"
OUTPUT_PATH = os.path.join(PROJECT_PATH, "OUTPUTS")
MODEL_OUTPUT_PATH = os.path.join(OUTPUT_PATH, "MODELING")

os.makedirs(MODEL_OUTPUT_PATH, exist_ok=True)

CLEAN_FILE = os.path.join(OUTPUT_PATH, "cleaned_athletes_dataset.csv")


# ----------------------------------------------------------
# 2. Load Cleaned Dataset
# ----------------------------------------------------------

df = pd.read_csv(CLEAN_FILE)

# When pandas reads the CSV, "None" can be interpreted as missing.
# We recode missing Medal values back to "None".
df["Medal"] = df["Medal"].fillna("None")

# Recreate Medal_Won if it does not already exist.
df["Medal_Won"] = np.where(df["Medal"] == "None", 0, 1)

print("\n--- CLEANED DATA LOADED ---")
print("Shape:", df.shape)

print("\n--- TARGET DISTRIBUTION ---")
print(df["Medal_Won"].value_counts())
print(df["Medal_Won"].value_counts(normalize=True).round(3))


# ----------------------------------------------------------
# 3. Define Target and Features
# ----------------------------------------------------------

target = "Medal_Won"
y = df[target]

# Drop columns that should not be used as predictors.
# These include identifiers and variables that directly reveal the target.
drop_cols = [
    "Athlete_ID",
    "Athlete_Name",
    "Medal",
    "Medal_Won",
    "Gold_Won",
    "Medal_Group"
]

existing_drop_cols = [col for col in drop_cols if col in df.columns]

X = df.drop(columns=existing_drop_cols)

# Identify categorical and numerical features automatically.
categorical_features = X.select_dtypes(include=["object"]).columns.tolist()
numerical_features = X.select_dtypes(include=["int64", "float64"]).columns.tolist()

print("\n--- FEATURE SETUP ---")
print("Categorical features:", categorical_features)
print("Numerical features:", numerical_features)
print("X shape:", X.shape)
print("y shape:", y.shape)


# ----------------------------------------------------------
# 4. Train-Test Split
# ----------------------------------------------------------
# Stratify preserves the medal/no-medal class balance in train and test sets.

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

print("\n--- TRAIN / TEST SPLIT ---")
print("X_train:", X_train.shape)
print("X_test:", X_test.shape)
print("y_train distribution:")
print(y_train.value_counts())


# ----------------------------------------------------------
# 5. Preprocessing
# ----------------------------------------------------------
# Numeric features are standardized.
# Categorical features are one-hot encoded.

preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), numerical_features),
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features)
    ]
)

# Fit preprocessing on training data only to avoid data leakage.
X_train_processed = preprocessor.fit_transform(X_train)
X_test_processed = preprocessor.transform(X_test)

# Get feature names after preprocessing.
encoded_feature_names = preprocessor.named_transformers_["cat"].get_feature_names_out(categorical_features)
all_feature_names = numerical_features + list(encoded_feature_names)

# Convert processed matrices to DataFrames for SMOTE and interpretability.
X_train_processed_df = pd.DataFrame(
    X_train_processed.toarray() if hasattr(X_train_processed, "toarray") else X_train_processed,
    columns=all_feature_names,
    index=X_train.index
)

X_test_processed_df = pd.DataFrame(
    X_test_processed.toarray() if hasattr(X_test_processed, "toarray") else X_test_processed,
    columns=all_feature_names,
    index=X_test.index
)

print("\n--- PREPROCESSING COMPLETE ---")
print("Processed training shape:", X_train_processed_df.shape)
print("Processed test shape:", X_test_processed_df.shape)


# ----------------------------------------------------------
# 6. Handle Class Imbalance with SMOTE
# ----------------------------------------------------------
# SMOTE is applied ONLY to the training set to avoid data leakage.

smote = SMOTE(random_state=42)

X_train_resampled, y_train_resampled = smote.fit_resample(
    X_train_processed_df,
    y_train
)

print("\n--- CLASS BALANCE AFTER SMOTE ---")
print("Original training distribution:")
print(y_train.value_counts())

print("\nResampled training distribution:")
print(y_train_resampled.value_counts())


# ----------------------------------------------------------
# 7. Train Logistic Regression Model
# ----------------------------------------------------------

log_reg_model = LogisticRegression(
    random_state=42,
    solver="liblinear",
    class_weight="balanced",
    max_iter=1000
)

log_reg_model.fit(X_train_resampled, y_train_resampled)


# ----------------------------------------------------------
# 8. Predict and Evaluate
# ----------------------------------------------------------

y_pred = log_reg_model.predict(X_test_processed_df)
y_pred_proba = log_reg_model.predict_proba(X_test_processed_df)[:, 1]

accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
roc_auc = roc_auc_score(y_test, y_pred_proba)

metrics_df = pd.DataFrame({
    "Model": ["Logistic Regression + SMOTE"],
    "Accuracy": [accuracy],
    "Precision": [precision],
    "Recall": [recall],
    "F1_Score": [f1],
    "AUC_ROC": [roc_auc]
})

print("\n--- LOGISTIC REGRESSION MODEL PERFORMANCE ---")
print(metrics_df.round(4))

metrics_path = os.path.join(MODEL_OUTPUT_PATH, "logistic_regression_metrics.csv")
metrics_df.to_csv(metrics_path, index=False)

print("\nMetrics saved to:")
print(metrics_path)

print("\n--- CLASSIFICATION REPORT ---")
print(classification_report(y_test, y_pred, zero_division=0))

report_df = pd.DataFrame(
    classification_report(y_test, y_pred, output_dict=True, zero_division=0)
).transpose()

report_path = os.path.join(MODEL_OUTPUT_PATH, "logistic_regression_classification_report.csv")
report_df.to_csv(report_path)

print("\nClassification report saved to:")
print(report_path)


# ----------------------------------------------------------
# 9. Confusion Matrix
# ----------------------------------------------------------

cm = confusion_matrix(y_test, y_pred)

fig, ax = plt.subplots(figsize=(6, 5))

disp = ConfusionMatrixDisplay(
    confusion_matrix=cm,
    display_labels=["No Medal", "Medal"]
)

disp.plot(
    cmap="Blues",
    values_format="d",
    ax=ax,
    colorbar=False
)

plt.title("Logistic Regression Confusion Matrix", fontsize=13, weight="bold")
plt.xlabel("Predicted Outcome")
plt.ylabel("Actual Outcome")

plt.tight_layout()
cm_path = os.path.join(MODEL_OUTPUT_PATH, "logistic_regression_confusion_matrix.png")
plt.savefig(cm_path, dpi=300)
plt.show()

print("\nConfusion matrix saved to:")
print(cm_path)


# ----------------------------------------------------------
# 10. ROC Curve
# ----------------------------------------------------------

fpr, tpr, thresholds = roc_curve(y_test, y_pred_proba)

plt.figure(figsize=(7, 5))

plt.plot(fpr, tpr, label=f"Logistic Regression (AUC = {roc_auc:.2f})")
plt.plot([0, 1], [0, 1], linestyle="--", label="Random Classifier")

plt.title("ROC Curve — Logistic Regression", fontsize=13, weight="bold")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.legend(frameon=False)

plt.tight_layout()
roc_path = os.path.join(MODEL_OUTPUT_PATH, "logistic_regression_roc_curve.png")
plt.savefig(roc_path, dpi=300)
plt.show()

print("\nROC curve saved to:")
print(roc_path)


# ----------------------------------------------------------
# 11. Logistic Regression Feature Importance
# ----------------------------------------------------------
# For logistic regression, coefficients show direction and strength.
# We use absolute coefficients for importance ranking.

coef_df = pd.DataFrame({
    "Feature": all_feature_names,
    "Coefficient": log_reg_model.coef_[0]
})

coef_df["Abs_Coefficient"] = coef_df["Coefficient"].abs()

coef_df = coef_df.sort_values("Abs_Coefficient", ascending=False)

coef_path = os.path.join(MODEL_OUTPUT_PATH, "logistic_regression_coefficients.csv")
coef_df.to_csv(coef_path, index=False)

print("\n--- TOP 15 LOGISTIC REGRESSION FEATURES ---")
print(coef_df.head(15))

print("\nCoefficient table saved to:")
print(coef_path)

top_coef = coef_df.head(15).sort_values("Abs_Coefficient")

plt.figure(figsize=(8, 6))
plt.barh(top_coef["Feature"], top_coef["Abs_Coefficient"])

plt.title("Top Logistic Regression Feature Effects", fontsize=13, weight="bold")
plt.xlabel("Absolute Coefficient")
plt.ylabel("Feature")

plt.tight_layout()
coef_chart_path = os.path.join(MODEL_OUTPUT_PATH, "logistic_regression_feature_effects.png")
plt.savefig(coef_chart_path, dpi=300)
plt.show()

print("\nFeature effects chart saved to:")
print(coef_chart_path)


# ----------------------------------------------------------
# 12. Prediction Test: 7 Named Athletes
# ----------------------------------------------------------
# The competition requires predictions for selected named athletes.

specific_athletes_names = [
    "Jordan Stolz",
    "Mikaela Shiffrin",
    "Connor McDavid",
    "Courtney Sarault",
    "Elana Meyers Taylor",
    "Deanna Stellato-Dudek",
    "Metodej Jilek"
]

specific_athletes_df = df[df["Athlete_Name"].isin(specific_athletes_names)].copy()

missing_athletes = sorted(set(specific_athletes_names) - set(specific_athletes_df["Athlete_Name"]))

if missing_athletes:
    print("\nWARNING: These named athletes were not found in the dataset:")
    print(missing_athletes)

if len(specific_athletes_df) > 0:
    X_specific = specific_athletes_df.drop(columns=existing_drop_cols)

    X_specific_processed = preprocessor.transform(X_specific)

    X_specific_processed_df = pd.DataFrame(
        X_specific_processed.toarray() if hasattr(X_specific_processed, "toarray") else X_specific_processed,
        columns=all_feature_names,
        index=X_specific.index
    )

    specific_predictions = log_reg_model.predict(X_specific_processed_df)
    specific_probabilities = log_reg_model.predict_proba(X_specific_processed_df)[:, 1]

    results_df = specific_athletes_df[
        ["Athlete_Name", "Country", "Sport", "Medal", "Medal_Won"]
    ].copy()

    results_df["Predicted_Medal_Won"] = specific_predictions
    results_df["Probability_Medal_Won"] = specific_probabilities
    results_df["Predicted_Outcome"] = results_df["Predicted_Medal_Won"].map({
        1: "Medal",
        0: "No Medal"
    })

    results_df = results_df.sort_values("Probability_Medal_Won", ascending=False)

    print("\n--- PREDICTIONS FOR 7 NAMED ATHLETES ---")
    print(results_df)

    named_pred_path = os.path.join(MODEL_OUTPUT_PATH, "logistic_regression_named_athlete_predictions.csv")
    results_df.to_csv(named_pred_path, index=False)

    print("\nNamed athlete predictions saved to:")
    print(named_pred_path)

else:
    print("\nNo named athletes found in dataset. Prediction test skipped.")


# ----------------------------------------------------------
# 13. Save Test Set Predictions
# ----------------------------------------------------------

test_predictions_df = X_test.copy()
test_predictions_df["Actual_Medal_Won"] = y_test.values
test_predictions_df["Predicted_Medal_Won"] = y_pred
test_predictions_df["Probability_Medal_Won"] = y_pred_proba

test_pred_path = os.path.join(MODEL_OUTPUT_PATH, "logistic_regression_test_predictions.csv")
test_predictions_df.to_csv(test_pred_path, index=False)

print("\nTest set predictions saved to:")
print(test_pred_path)

print("\n--- LOGISTIC REGRESSION MODELING COMPLETE ---")
